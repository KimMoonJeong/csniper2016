import threading, time
import PyoConnect
import sys
import math
class utils():
   def connMyo(self):
        if self.checker:
	    self.checker = False
	    self.th = MyoThread("myoConn")
	    self.th.start()
	    
    def disconnMyo(self):
	self.checker = True
	print("stop")
	self.th.stop()
	
    def configStup(self,th):

	th = MyoThread("startupConn")
	th.start()
	self.th.join()
	self.count_List()

	
	f = open("emgAverage.txt", "w")
	data = "fir:%f\nsec:%f\nthir:%f\nforth:%f\nfifth:%f\nsixth:%f\nsevth:%f\neith:%f"%(self.average[0], self.average[1], self.average[2], self.average[3], self.average[4], self.average[5], self.average[6],self.average[7])
	print("output average data")	
	f.write(data)

	print("output stdev data")
	f = open("emgStdev.txt", "w")
	data = "fir:%f\nsec:%f\nthir:%f\nforth:%f\nfifth:%f\nsixth:%f\nsevth:%f\neith:%f"%(self.stdev[0], self.stdev[1], self.stdev[2], self.stdev[2], self.stdev[4], self.stdev[5], self.stdev[6], self.stdev[7])
	f.write(data)	
	f.close()
  
    def configStart(self):
	self.
 	self.setLayout(self.configLayout)
   	
	
	
     	
    def count_List(self):
		roll_list = []
		yaw_list = []
		pitch_list = []	
		self.count_roll = []	
		self.count_yaw = []	
		self.count_pitch = []	
		del(self.count_roll[:])
		del(self.count_pitch[:])
		del(self.count_yaw[:])
		roll_list = self.th.getRollData()
		yaw_list = self.th.getYawData()
		pitch_list = self.th.getPitchData()
		i = 0
		roll_sum = 0
		pitch_sum = 0
		yaw_sum = 0
	
		for data in roll_list:
		    
		    roll_sum = roll_sum + data
		    print("sdfsafasf", roll_sum)
   		    pitch_sum = pitch_sum + pitch_list[i]
		    yaw_sum = yaw_sum + yaw_list[i]
		    i = i +1	    
		self.average = [roll_sum / i, pitch_sum / i, yaw_sum / i]
		
		i =0
		roll_sum = 0
		pitch_sum = 0
		yaw_sum = 0
		for data in roll_list:
			  
	  	    roll_sum = roll_sum +  math.pow(data, 2)
		    pitch_sum = pitch_sum + math.pow(pitch_list[i],2)
		    yaw_sum = yaw_sum + math.pow(yaw_list[i],2)
		    i = i + 1
		rollV = roll_sum / i - math.pow(self.average[0], 2)
		pitchV = pitch_sum / i - math.pow(self.average[1], 2)
		yawV = yaw_sum / i - math.pow(self.average[2], 2)

		self.stdev = [math.sqrt(rollV), math.sqrt(pitchV), math.sqrt(yawV)]
		datas = [self.average, self.stdev]
		return datas



class MyoThread(threading.Thread):
    def __init__(self, connType):
	
	self.connType = connType
	threading.Thread.__init__(self)
	self.checker = True
	self.listRoll = []
	self.listPitch = []
	self.listYaw = []
	self.m = PyoConnect.Myo(sys.argv[1] if len(sys.argv) >= 2 else None)
	print("use port") 
    def run(self):
	if self.connType == 'myoConn':	
	    self.m.connect()
  	    print("connected")
	    while self.checker:
		self.m.run()
		self.currentState = self.m.getcurrentState()
		if self.currentState == 1:
		    print("start-up!!")
		
	 	    self.m.disconnect()
		
		
	elif self.connType == 'configConn':
       	    self.m.connect()
	    time.sleep(2)
	    count = 0
	    checker = True	
	    while checker:
		if count >= 400 :
		    checker = False 	
 	                
		    print("disconnect")                
		    self.m.disconnect()	        
		    return
		count = count + 1	    
	        self.m.run()
	        self.listRoll.append(float(self.m.getRollW()))
    	        self.listPitch.append(float(self.m.getPitchW()))
	        self.listYaw.append(float(self.m.getYawW()))
		#print(self.m.getRollW(), self.m.getPitchW(), self.m.getYawW())


	elif self.connType == 'startupConn':
       	    self.m.connect()
	    time.sleep(2)
	    count = 0
	    checker = True	
	    while checker:
		if count >= 400 :
		    checker = False 	
 	                
		    print("disconnect")                
		           
		    return
		count = count + 1	    
	        self.m.run()
		
	        #print(int(m.getconfigedRollW()) , int(m.getconfigedPitchW()), m.getconfigedYawW())
    def stop(self):
	self.checker = False
	self.m.disconnect()
    def getRollData(self):
	return self.listRoll
    def getPitchData(self):
	return self.listPitch
    def getYawData(self):
	return self.listYaw



if __name__ == '__main__' :
    import sys
    app = QtGui.QApplication(sys.argv)
    dialog = Dialog()
    sys.exit(dialog.exec_())	
