'''
	PyoConnect v0.1
	
	Author:
	  Fernando Cosentino - fbcosentino@yahoo.com.br
	  
	Official source:
	  http://www.fernandocosentino.net/pyoconnect
	  
	Based on the work of dzhu: https://github.com/dzhu/myo-raw
	
	License:
		Use at will, modify at will. Always keep my name in this file as original author. And that's it.
	
	Steps required (in a clean debian installation) to use this library:
		// permission to ttyACM0 - must restart linux user after this
		sudo usermod -a -G dialout $USER

		// dependencies
		apt-get install python-pip
		pip install pySerial --upgrade
		pip install enum34
		pip install PyUserInput
		apt-get install python-Xlib

		// now reboot	
'''

from __future__ import print_function
from collections import Counter, deque
import sys
import time
from subprocess import Popen, PIPE
import re
import math
import Position
import positionTest
import numpy as np

try:
    from sklearn import neighbors, svm
    HAVE_SK = True
except ImportError:
    HAVE_SK = False


try:
    from pymouse import PyMouse
    pmouse = PyMouse()
except:
    print("PyMouse error: No mouse support")
    pmouse = None

try:
    from pykeyboard import PyKeyboard
    pkeyboard = PyKeyboard()
except:
    print("PyKeyboard error: No keyboard support")
    pkeyboard = None

from common import *
from myo_raw import MyoRaw, Pose, Arm, XDirection


SUBSAMPLE = 3
K = 15

class NNClassifier(object):
    '''A wrapper for sklearn's nearest-neighbor classifier that stores
    training data in vals0, ..., vals9.dat.'''

    def __init__(self):
        for i in range(10):
            with open('vals%d.dat' % i, 'ab') as f: pass
        self.read_data()

    def store_data(self, cls, vals):
	print("here is store_data   i will save with", cls)
        with open('vals%d.dat' % cls, 'ab') as f:
            f.write(pack('8H', *vals))

        self.train(np.vstack([self.X, vals]), np.hstack([self.Y, [cls]]))

    def read_data(self):
        X = []
        Y = []
        for i in range(10):
            X.append(np.fromfile('vals%d.dat' % i, dtype=np.uint16).reshape((-1, 8)))
            Y.append(i + np.zeros(X[-1].shape[0]))

        self.train(np.vstack(X), np.hstack(Y))

    def train(self, X, Y):
        self.X = X
        self.Y = Y
        if HAVE_SK and self.X.shape[0] >= K * SUBSAMPLE:
            self.nn = neighbors.KNeighborsClassifier(n_neighbors=K, algorithm='kd_tree')
            self.nn.fit(self.X[::SUBSAMPLE], self.Y[::SUBSAMPLE])
        else:
            self.nn = None

    def nearest(self, d):
        dists = ((self.X - d)**2).sum(1)
        ind = dists.argmin()
        return self.Y[ind]

    def classify(self, d):
        if self.X.shape[0] < K * SUBSAMPLE: return 0
        if not HAVE_SK: return self.nearest(d)
        return int(self.nn.predict(d)[0])
    	    


    




class Myo(MyoRaw):
    HIST_LEN = 25
    # ======== INIT ========
    def __init__(self, cls, tty=None):
	self.cls = cls

	self.history = deque([0] * Myo.HIST_LEN, Myo.HIST_LEN)
	self.history_cnt = Counter(self.history)
	
	
	self.last_pose = None
	self.pose_handlers = []    	

	self.current_pose = 0
    	self.current_gyro = None
    	self.current_accel = None
    	self.current_roll = 0
    	self.current_pitch = 0
    	self.current_yaw = 0
    	self.center_roll = 0
    	self.center_pitch = 0
    	self.center_yaw = 0
    	self.first_rot = 0
    	self.current_rot_roll = 0
    	self.current_rot_pitch = 0
    	self.current_rot_yaw = 0
    	self.configed_roll = 0
	self.configed_yaw = 0
	self.configed_pitch = 0
	
	self.rollW = 0
	self.pitchW = 0
	self.yawW = 0
	

        self.mov_history = ""
        self.gest_history = ""
        self.act_history = ""
    	self.setConfigData()
	
	self.current_position = 0
	self.posi = Position.Position()
	self.posi_history = []

	self.emgs = []
	self.emg = 0

        self.centered = 0
        
        MyoRaw.__init__(self, tty)

        self.add_emg_handler(self.emg_handler)
        self.add_imu_handler(self.imu_handler)

    
   
	
    # -------- INTERNAL HANDLERS --------    
    def emg_handler(self, emg, moving):   
	y = self.cls.classify(emg)
	self.history_cnt[self.history[0]] -= 1
	self.history_cnt[y] += 1
	self.history.append(y)
	r, n = self.history_cnt.most_common(1)[0]
	self.current_pose = self.history_cnt.most_common(1)[0][0]+1
        if self.last_pose is None or (n > self.history_cnt[self.last_pose] + 5 and n > Myo.HIST_LEN / 2):
            self.on_raw_pose(r)
            self.last_pose = r
	
    def add_raw_pose_handler(self,h):
	self.pose_handlers.append(h)

    def on_raw_pose(self, pose):
	for h in self.pose_handlers:
	    h(pose)

	

    def imu_handler(self, quat, acc, gyro):
	SCALE = 40
	ax, ay, az = acc
        qx, qy, qz, qw = quat
	

	norm = math.sqrt(math.pow(qx, 2) + math.pow(qy, 2) + math.pow(qz, 2) + math.pow(qw,2))
	
		

   	qx = qx/norm
        qy = qy/norm
        qz = qz/norm
        qw = qw/norm
		
	
	pitch = math.atan2(ay,az)*SCALE
	roll = math.atan2(ax,az)*SCALE
	
	
	self.current_quat = quat
        self.current_gyro = gyro
        self.current_accel = acc

        self.current_yaw = math.atan2(2.0*(qw*qz + qx*qy), 1.0 - 2.0 *(qy*qy + qz*qz))
        self.current_pitch = math.asin(2.0*(qw*qy-qz*qx))
        self.current_roll =  math.atan2(2.0*(qw*qx + qy*qz), 1.0 - 2.0*(qx*qx + qy*qy))   
    

	self.rollW = ((self.current_roll  + math.pi) / (math.pi * 2.0) * SCALE);
	self.pitchW = ((self.current_pitch + math.pi / 2.0) / math.pi * SCALE);
	self.yawW = ((self.current_yaw + math.pi) / (math.pi * 2.0) * SCALE);
 
	
	
	self.addPosition()
	self.check_posiHistory()
	print(self.getconfigedRollW(), self.getconfigedPitchW(), self.getconfigedYawW());
	print(self.posi_history)
	  	    		
    
    	
    	
    # -------- API --------    
    def getEmgs(self):
	data = self.emgs
	self.emgs = []
	return data

    def getRollW(self):
	value = self.rollW 
	return value
    def getPitchW(self):
	value = self.pitchW
	return value
    def getYawW(self):
	value = self.yawW
	return value



    def getconfigedRollW(self):
	value = self.rollW - self.configed_roll
	if value >= 21:
		value = self.rollW - 40 - self.configed_roll
	return value
    def getconfigedPitchW(self):
	value = self.pitchW - self.configed_pitch
	if value >= 21:
		value = self.pitchW - 40 - self.configed_pitch
	return value
    def getconfigedYawW(self):
	value = self.yawW - self.configed_yaw
	if value >= 21:
		value = self.yawW- 40 - self.configed_yaw
	return value
    
    def getRoll(self):
        return self.current_roll

    def getPitch(self):
        return self.current_pitcha

    def getYaw(self):
        return self.current_yaw

    def getString(self):
	pass
	
    	    
    # -------- API *NEW* functions --------
    def setConfigData(self):
	try:
	    f = open("config.txt", "r")
	    configedData = f.readlines()
	    self.configed_roll = float(configedData[0].split(":")[1])
	    self.configed_pitch = float(configedData[1].split(":")[1])
	    self.configed_yaw = float(configedData[2].split(":")[1])
		   
	except Exception as e:
	    print("no config.txt file so data set 0")
	try:
	    f2 = open("start.txt", "r")
 	    startupData = f2.readlines()
	    self.start_roll = float(startupData[0].split(":")[1])
	    self.start_pitch = float(startupData[1].split(":")[1])
	    self.start_yaw = float(startupData[2].split(":")[1])
	except Exception as e:
	    print("no start.txt file so data set 0")

  
    def setConfigRoll(self, init_roll):
	self.configed_roll = init_roll
    def setConfigYaw(self, init_yaw):
	self.configed_yaw = init_yaw
    def setConfigPitch(self, init_pitch):
	self.configed_pitch = init_pitch

    def addPosition(self):

	    self.posi.setPosition(self.getconfigedRollW(), self.getconfigedPitchW(), self.getconfigedYawW(), self.current_pose,self.configed_roll,self.configed_pitch,self.configed_yaw)
	    
	    if(self.current_position != self.posi.getPosition()):
   		self.current_position = self.posi.getPosition()
	        if self.current_position != 0:
		    
		    self.posi_history.append(self.current_position)		    

    def check_posiHistory(self):
	#check history and speak somthings
	check = positionTest.speak(self.posi_history)
	if check:
	   del self.posi_history[0:len(self.posi_history)]
    # -------- INTERNAL FUNCTIONS --------

  
    
 
	



