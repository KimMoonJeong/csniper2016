class Position():

	def __init__(self):	
		#current_position value is position of hands's number
		# position value '0' is not setted position
		self.current_position = 0

		
		self.position_data = []

		self.roll_stde = 0.35
		self.pitch_stde = 0.35
		self.yaw_stde = 0.35
		self.position_value = 0
		
	
		#read position data
		f = open("positionData.txt", "r")
	    	data = f.readlines()
		i = 0
		
		for k in data:
		  
		    self.position_data.append([float(data[i].split(':')[1].split(',')[0]),float(data[i].split(':')[1].split(',')[1]),float(data[i].split(':')[1].split(',')[2]),float(data[i].split(':')[1].split(',')[3])])
		    i = i+1



	def getPosition(self):
		return self.current_position
	
	def setPosition(self, roll_data, pitch_data, yaw_data, pose_data, cr, cp, cy):
		self.position_value = 0
		
		for data in self.position_data:
			print(data ,"[",roll_data,"", pitch_data,"", yaw_data,pose_data,"]")
			self.position_value = self.position_value + 1
			roll, pitch, yaw, pose = data
			
			if (roll - 6*self.roll_stde) < roll_data and (roll + 6*self.roll_stde) > roll_data and (pitch - 6*self.pitch_stde) < pitch_data and (pitch + 6*self.pitch_stde) > pitch_data and (yaw - 6*self.yaw_stde) < yaw_data and (yaw + 6*self.yaw_stde) > yaw_data:
				if pose == 0:
					self.current_position = self.position_value
				else:
					if pose == pose_data:
						self.current_position = self.position_value
				
	  
	
