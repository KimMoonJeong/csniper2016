import subprocess
import threading, time
import pygame
import Utils

'''
test1[0] : hi
test1[1] : sugo
test1[2] : gomab
test1[3] : tong yeoc
test1[4] : jang chi
test1[5] : ib ni da
'''
test1 = [[1,2,3,4,3],[1,2,4,3,4], [5,6,5],[7,8,7],[9,10],[11,12,11],[13,14,13]]
test2 = []
mp3_dir = ["hi.MP3", "hi.MP3","sugo.MP3","thanks.MP3","translate.MP3","device.MP3","hand.MP3"]


	
def speak(data):
	
	test2 = data
	size = len(test2)
	size2 = len(test1)
	count = 0;
	sound_player = "mpg321"	
	sound_file = "./sound/"
	for k in range(0, size2):
		size3 = len(test1[k])
		
		if(size == size3):
			count = 0		
			for k2 in range(0, size3):
				if(test2[k2] == test1[k][k2]):
					count = count + 1
			if count == size3:
				print("speak")
				sound_file = sound_file+mp3_dir[k]
				th = Utils.SoundThread(sound_file)
				th.start()
					
				return True
		if(size > size3):
			size4 = size - size3 + 1		
			for k2 in range(0 , size4):
				count = 0
				for k3 in range(0, size3):
					if test1[k][k3] == test2[k3+k2]:
						count = count + 1
			if count == size3:
				print("speak")
				sound_file = sound_file+mp3_dir[k]
				th = Utils.SoundThread(sound_file)
				th.start()
				
				
				return True
	return False

