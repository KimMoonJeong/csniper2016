import threading, time
import PyoConnect
import sys
import math
import pygame
import subprocess

class EMGHandler(object):
    def __init__(self, m):
        self.recording = -1
        self.m = m
        self.emg = (0,) * 8

    def __call__(self, emg, moving):
        self.emg = emg
	
        if self.recording >= 0:
	    print("here is EMGHandler", self.recording)
            self.m.cls.store_data(self.recording, emg)


def count_List(th):
	roll_list = []
	yaw_list = []
	pitch_list = []	
	count_roll = []	
	count_yaw = []	
	count_pitch = []	
	del(count_roll[:])
	del(count_pitch[:])
	del(count_yaw[:])
	roll_list = th.getRollData()
	yaw_list = th.getYawData()
	pitch_list = th.getPitchData()
	print(roll_list)
	i = 0
	roll_sum = 0
	pitch_sum = 0
	yaw_sum = 0
	
	for data in roll_list:
		    
	    roll_sum = roll_sum + data
	    pitch_sum = pitch_sum + pitch_list[i]
	    yaw_sum = yaw_sum + yaw_list[i]
	    i = i +1	    
	average = [roll_sum / i, pitch_sum / i, yaw_sum / i]
	
	i =0
	roll_sum = 0
	pitch_sum = 0
	yaw_sum = 0
	for data in roll_list:
			  
	    roll_sum = roll_sum +  math.pow(data, 2)
	    pitch_sum = pitch_sum + math.pow(pitch_list[i],2)
	    yaw_sum = yaw_sum + math.pow(yaw_list[i],2)
	    i = i + 1
	rollV = roll_sum / i - math.pow(average[0], 2)
	pitchV = pitch_sum / i - math.pow(average[1], 2)
	yawV = yaw_sum / i - math.pow(average[2], 2)

	stdev = [math.sqrt(rollV), math.sqrt(pitchV), math.sqrt(yawV)]
	datas = [average, stdev]
	return datas


class SoundThread(threading.Thread):
    def __init__(self, file_dir):
	threading.Thread.__init__(self)
	self.file_dir = file_dir
	print(self.file_dir)
	
    def run(self):
	pygame.mixer.init()
	pygame.mixer.music.load(self.file_dir)
	pygame.mixer.music.play(1)



class MyoThread(threading.Thread):
    def __init__(self, connType, value):
	
	self.connType = connType
	threading.Thread.__init__(self)
	self.checker = True
	self.listRoll = []
	self.listPitch = []
	self.listYaw = []

	self.connType = connType
	self.value = value

	self.m = PyoConnect.Myo(PyoConnect.NNClassifier(), sys.argv[1] if len(sys.argv) >= 2 else None)
	

  
    def run(self):
	if self.connType == 'myoConn':	
	    self.m.connect()
  	    print("connected")
	    while self.checker:
		self.m.run()
		
	elif self.connType == 'configConn':
	    
       	    self.m.connect()
	    count = 0
	    checker2 = True
	    while checker2:
		print("this is checker ", checker2)
		if count >= 400 :
		    print("cofunt 400 ")
		    checker2 = False 	
 	            self.disconnect()    
		    print("disconnect")                
		    	        
		else :
		   
   		    count = count + 1	    
	            self.m.run()
		    			
		    self.listRoll.append(float(self.m.getRollW()))
		  
		    self.listPitch.append(float(self.m.getPitchW()))
		    
		    self.listYaw.append(float(self.m.getYawW()))
	            
			    

                
		#print(self.m.getRollW(), self.m.getPitchW(), self.m.getYawW())

	elif self.connType == 'emgRecord':
	   
	    hnd = EMGHandler(self.m)
	    self.m.add_emg_handler(hnd)
	    self.m.connect()
	    count = 0
	    
	    checker2 = True
	    while checker2:
		if count >= 400:
		    checker2 = False
		    hnd.recording = -1
		    self.m.disconnect()
		else :
	 	    self.m.run()	
	    	    hnd.recording = self.value  
		    count = count + 1 
 
    def stop(self):
	self.checker = False
    def getRollData(self):
	return self.listRoll
    def getPitchData(self):
	return self.listPitch
    def getYawData(self):
	return self.listYaw



if __name__ == '__main__' :
    import sys
    app = QtGui.QApplication(sys.argv)
    dialog = Dialog()
    sys.exit(dialog.exec_())	
