'''
did first in terminal

	apt-get update
	ppt-get upgrade
	apt-get install python-pip
	pip install pySerial --upgrade
	pip install enum34
	pip install PyUserInput
	apt-get install python-Xlib
'''


from PyQt4 import QtGui
from PyQt4 import QtCore
import sys
import Utils



class Config(QtGui.QDialog): 

    def __init__(self):
        super(Config, self).__init__()

	self.checker = True
        
	#----- set layout
        self.mainLayout = QtGui.QGridLayout()
        self.Init_Conf_Group = QtGui.QGroupBox()
        self.Pose_Conf_Group = QtGui.QGroupBox()
        self.Main_Group =  QtGui.QGroupBox()
        
        self.createMainLayout()
        self.createInitConfigLayout()
        self.createPoseConfigLayout()
   	

        self.mainLayout = QtGui.QGridLayout()
        self.mainLayout.addWidget(self.Main_Group)
        


	#---- conn event 
        self.init_Config_BTN.clicked.connect(self.toInit)
        self.pose_Config_BTN.clicked.connect(self.toPose)  
        self.Exit_BTN.clicked.connect(self.toMain1)
        self.Exit2_BTN.clicked.connect(self.toMain2)
        self.ConfigBtn.clicked.connect(self.initConfig)
	self.conn_Myo_BTN.clicked.connect(self.connMyo)
	self.disconn_Myo_BTN.clicked.connect(self.disconnMyo)
	self.First_Pose_BTN.clicked.connect(self.recordFir)       
	self.Second_Pose_BTN.clicked.connect(self.recordSec)
	self.Third_Pose_BTN.clicked.connect(self.recordThird)
	self.Fourth_Pose_BTN.clicked.connect(self.recordFour)
	self.Fifth_Pose_BTN.clicked.connect(self.recordFif)
	self.Sixth_Pose_BTN.clicked.connect(self.recordSix)
	self.Seventh_Pose_BTN.clicked.connect(self.recordSev)
	self.Eighth_Pose_BTN.clicked.connect(self.recordEigh)
	self.Ninth_Pose_BTN.clicked.connect(self.recordNin)
	self.Tenth_Pose_BTN.clicked.connect(self.recordTen)



        self.setFixedHeight(472)
        self.setFixedWidth(548)	
        self.setLayout(self.mainLayout)
      
#------------ for create layout ---------------------        
    def createMainLayout(self):
       
     
     
        self.conn_Myo_BTN = QtGui.QPushButton("connect")
	self.disconn_Myo_BTN = QtGui.QPushButton("disconnect")
        self.init_Config_BTN = QtGui.QPushButton("init Config")
        self.pose_Config_BTN = QtGui.QPushButton("pose Config")

        self.FirLayout = QtGui.QGridLayout()
        self.FirLayout.addWidget(self.conn_Myo_BTN)
	self.FirLayout.addWidget(self.disconn_Myo_BTN)
        self.FirLayout.addWidget(self.init_Config_BTN)
        self.FirLayout.addWidget(self.pose_Config_BTN)
        
        self.Main_Group.setLayout(self.FirLayout)
        
    def createInitConfigLayout(self):
       
        
        self.Explane_Image = QtGui.QLabel()
        pixmap = QtGui.QPixmap("config_posi.jpg")
        self.Explane_Image.setPixmap(pixmap)
         
        Explane_Label = QtGui.QLabel("please position like picture")
        
        self.ConfigBtn = QtGui.QPushButton("Config Start")
        
        self.Exit_BTN = QtGui.QPushButton("to Main")
           
        
        self.Init_Config_Layout = QtGui.QGridLayout()
        self.Init_Config_Layout.addWidget(self.Explane_Image)
        self.Init_Config_Layout.addWidget(Explane_Label) 
        self.Init_Config_Layout.addWidget(self.ConfigBtn)  
        self.Init_Config_Layout.addWidget(self.Exit_BTN)
 
        self.Init_Conf_Group.setLayout(self.Init_Config_Layout)
    def createPoseConfigLayout(self):
        
        self.First_Pose_BTN = QtGui.QPushButton("one finger Pose Recording")
        self.Second_Pose_BTN = QtGui.QPushButton("ggagji Pose Recording")
	self.Third_Pose_BTN = QtGui.QPushButton("rest Pose Recording")
	self.Fourth_Pose_BTN = QtGui.QPushButton("fist Pose Recording")
	self.Fifth_Pose_BTN = QtGui.QPushButton("umji Pose Recording")
	self.Sixth_Pose_BTN = QtGui.QPushButton("6th Pose Recording")
	self.Seventh_Pose_BTN = QtGui.QPushButton("7th Pose Recording")
	self.Eighth_Pose_BTN = QtGui.QPushButton("8th Pose Recording")
	self.Ninth_Pose_BTN = QtGui.QPushButton("9th Pose Recording")
	self.Tenth_Pose_BTN = QtGui.QPushButton("10th Pose Recording")


        self.Explane_Area = QtGui.QTextEdit("push the button and set pose wait 6 sec\nrecord will start")
        self.Exit2_BTN = QtGui.QPushButton("to Main")
        
        self.Pose_Config_Layout = QtGui.QGridLayout()
        self.Pose_Config_Layout.addWidget(self.First_Pose_BTN)
        self.Pose_Config_Layout.addWidget(self.Second_Pose_BTN)
	self.Pose_Config_Layout.addWidget(self.Third_Pose_BTN)
	self.Pose_Config_Layout.addWidget(self.Fourth_Pose_BTN)
        self.Pose_Config_Layout.addWidget(self.Fifth_Pose_BTN)
	self.Pose_Config_Layout.addWidget(self.Sixth_Pose_BTN)
 	self.Pose_Config_Layout.addWidget(self.Seventh_Pose_BTN)
        self.Pose_Config_Layout.addWidget(self.Eighth_Pose_BTN)
	self.Pose_Config_Layout.addWidget(self.Ninth_Pose_BTN)
 	self.Pose_Config_Layout.addWidget(self.Tenth_Pose_BTN)
       
        self.Pose_Config_Layout.addWidget(self.Explane_Area)
        self.Pose_Config_Layout.addWidget(self.Exit2_BTN)

        
      
        self.Pose_Conf_Group.setLayout(self.Pose_Config_Layout)
    
#-----------------------------------------------------


#----- for replace layout ----------
    def toInit(self):
	self.deleteWidget()
        self.Explane_Image.show()
        self.mainLayout.addWidget(self.Init_Conf_Group)

        print("width : ",self.width(), "  height  ", self.height())
    def toPose(self):
        self.deleteWidget()
        self.mainLayout.addWidget(self.Pose_Conf_Group)
        
        print("width : ",self.width(), "  height  ", self.height())
    def toMain1(self):   
        self.deleteWidget()
	self.mainLayout.addWidget(self.Main_Group)
       
    def toMain2(self):
        self.deleteWidget()
	self.mainLayout.addWidget(self.Main_Group)
        
    def deleteWidget(self):
        for i in reversed(range(self.mainLayout.count())): 
            self.mainLayout.itemAt(i).widget().setParent(None)
	
   
#--------------------------------------	

# -------------button events ----------------------------
    

    def connMyo(self):
	if self.checker:
	    self.checker = False
	    self.th = Utils.MyoThread("myoConn",0)
	    self.th.start()
    def disconnMyo(self):
	self.checker = True
	print("stop")
	self.th.stop()

    def initConfig(self):

	self.th = Utils.MyoThread("configConn",0)
	self.th.start()
	self.th.join()

	datas = Utils.count_List(self.th)
	average = datas[0]
	stdev = datas[1]

	print("average")
	print(average)
	print("stdev")
	print(stdev)

	f = open("config.txt", "w")
	data = "roll:%f\npitch:%f\nyaw:%f"%(average[0], average[1], average[2])
	print("output average data")	
	f.write(data)

	print("output stdev data")
	f = open("dataStdev.txt", "w")
	data = "rollStdev:%f\npitchStdev:%f\nyawStdev:%f"%(stdev[0], stdev[1], stdev[2])
	f.write(data)	
	f.close()

    def recordFir(self):
	self.recordPose(0)
    def recordSec(self):
	self.recordPose(1)
    def recordThird(self):
	self.recordPose(2)
    def recordFour(self):
	self.recordPose(3)
    def recordFif(self):
	self.recordPose(4)
    def recordSix(self):
	self.recordPose(5)    
    def recordSev(self):
	self.recordPose(6)
    def recordEigh(self):
	self.recordPose(7)
    def recordNin(self):
	self.recordPose(8)
    def recordTen(self):
	self.recordPose(9)
#--------------- others --------------

    def recordPose(self, value):
	self.th = Utils.MyoThread("emgRecord", value)
	self.th.start()
	self.th.join()
	
	QtGui.QMessageBox.information(self, "alert!!","record complete")



app = QtGui.QApplication(sys.argv)
dialog = Config()
sys.exit(dialog.exec_())    



